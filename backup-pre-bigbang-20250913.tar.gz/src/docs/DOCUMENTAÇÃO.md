# Documentação da API - Eklesia Konecta

Este documento detalha todos os endpoints, exemplos de uso e integrações do backend Eklesia Konecta.

## Sumário
- [Módulos do Sistema](#módulos-do-sistema)
- [Autenticação](#autenticação)
- [Usuários](#usuários)
- [Congregações](#congregações)
- [Membros](#membros)
- [Células](#células)
- [Discipulado](#discipulado)
- [Ofertas](#ofertas)
- [Despesas](#despesas)
- [Relatórios](#relatórios)
- [Dashboard](#dashboard)
 - [Snapshot Financeiro Mensal](#snapshot-financeiro-mensal)
- [Comprovantes (Fotos do Talão)](#comprovantes-fotos-do-talão)
- [Perfis e Permissões](#perfis-e-permissões)
- [Testes Automatizados](#testes-automatizados)
- [Deploy](#deploy)
- [Observações Gerais](#observações-gerais)

---

## Módulos do Sistema

- **Igrejas/Congregações**: Cadastro, atualização, remoção, localização.
- **Usuários/Admin**: Cadastro, autenticação, permissões, logs de acesso.
- **Células**: Cadastro, reuniões, frequência, relatórios.
- **Discipulado**: Cadastro de discipuladores/discipulandos, acompanhamento, relatórios.
- **Financeiro**: Ofertas, despesas, relatórios financeiros, upload de comprovantes.
- **Dashboard**: Resumo financeiro anual.
- **Notificações**: Envio de e-mails e WhatsApp.
- **Logs/Auditoria**: Registro de ações administrativas.
- **Relatórios**: Relatórios mensais, PDF, exportação.
- **Lives/Web Rádio**: Cadastro e listagem de transmissões ao vivo (se aplicável).

---

## Autenticação & Onboarding

### Fluxo de Onboarding Público (Nova Igreja)
`POST /api/cadastro-inicial`
```json
{
  "nomeIgreja": "Igreja Exemplo",
  "nomePastor": "Fulano",
  "emailPastor": "pastor@exemplo.com",
  "senhaPastor": "SenhaForte123"
}
```
Resposta:
```json
{
  "success": true,
  "message": "Cadastro inicial realizado com sucesso!",
  "igreja": { "nome": "Igreja Exemplo", "schema": "igreja_exemplo_ab12cd34" },
  "pastor": { "nome": "Fulano", "email": "pastor@exemplo.com" }
}
```

Use o `schema` retornado para logar e operar no tenant.

### Headers Multi‑Tenant Obrigatórios
```
schema: <schema_da_igreja>
Authorization: Bearer <token>
```
Sem o header `schema` as rotas protegidas rejeitam a requisição. O login também exige o header.

## Autenticação

### Registrar usuário

`POST /auth/register`

**Body:**
```json
{
  "nome": "Admin",
  "email": "admin@teste.com",
  "senha": "123456",
  "perfil": "admin", // "admin", "pastor", "tesoureiro", "dirigente"
  "congregacaoId": 1 // (opcional para admin/pastor)
}
```

### Login

`POST /auth/login` (enviar header `schema` do tenant)

**Body:**
```json
{
  "email": "admin@teste.com",
  "senha": "123456"
}
```
**Resposta:**  
```json
{
  "token": "JWT_TOKEN",
  "usuario": {
    "id": 1,
    "nome": "Admin",
    "email": "admin@teste.com",
    "perfil": "admin"
  }
}
```

**Use o token JWT no header das próximas requisições:**
```
Authorization: Bearer SEU_TOKEN_AQUI
```

---

## Usuários

> Importante: criação de igreja autenticada via `/api/igrejas` agora é apenas para ADMIN dentro do schema ou SUPERUSER no schema `public`. Para a maioria dos fluxos use sempre o onboarding público.


### Listar usuários (admin)
`GET /api/usuarios`

### Criar usuário (admin)
`POST /api/usuarios`
**Body:**
```json
{
  "nome": "João",
  "email": "joao@teste.com",
  "senha": "123456",
  "perfil": "TESOUREIRO",
  "congregacaoId": 2
}
```

### Editar usuário (admin)
`PUT /api/usuarios/:id`

### Deletar usuário (admin)
`DELETE /api/usuarios/:id`

### Redefinir senha (admin)
`PATCH /api/usuarios/:id/reset-password`
**Body:**
```json
{
  "novaSenha": "novaSenha123"
}
```

### Trocar a própria senha (usuário autenticado)
`PATCH /api/usuarios/change-password`
**Body:**
```json
{
  "senhaAtual": "senha_antiga",
  "novaSenha": "nova_senha"
}
```

---

## Congregações


### Listar congregações
`GET /api/congregacoes`

### Criar congregação
`POST /api/congregacoes`
**Body:**
```json
{
  "nome": "Congregação Central",
  "endereco": "Rua Principal, 123",
  "churchId": 1
}
```

---

## Membros


### Listar membros
`GET /api/membros?congregacaoId=1`

### Criar membro
`POST /api/membros`
**Body:**
```json
{
  "nome": "Maria",
  "email": "maria@teste.com",
  "congregacaoId": 1,
  "celulaId": 1
}
```

---

## Células


### Listar células
`GET /api/celulas?congregacaoId=1`

### Criar célula
`POST /api/celulas`
**Body:**
```json
{
  "nome": "Célula Central",
  "congregacaoId": 1,
  "liderId": 2
}
```

### Relatórios de células

`GET /relatorios/celulas?dataInicio=2024-01-01&dataFim=2024-06-30`

---

## Discipulado

### Listar discipulados

`GET /discipulado?congregacaoId=1`

### Relatório de discipulado

`GET /relatorios/discipulado/por-discipulador?dataInicio=2024-01-01&dataFim=2024-06-30`

---

## Ofertas


### Listar ofertas
`GET /api/offerings?congregacaoId=1`

### Criar oferta
`POST /api/offerings`
**Body:**
```json
{
  "memberId": 1,
  "congregacaoId": 1,
  "type": "dizimo", // ou "oferta"
  "valor": 100,
  "data": "2025-06-17",
  "service": "domingo",
  "receiptPhoto": "/uploads/1/2025-6/arquivo.jpg" // opcional
}
```

### Upload de comprovante (foto do talão)

`POST /ofertas/upload-receipt`

**Body (form-data):**
- `congregacaoId`: 1
- `ano`: 2025
- `mes`: 6
- `receiptPhoto`: (arquivo)

**Resposta:**
```json
{
  "filePath": "/uploads/1/2025-6/arquivo.jpg"
}
```

### Atualizar comprovante de uma oferta

`PATCH /ofertas/:id/receipt-photo`

**Body:**
```json
{
  "receiptPhoto": "/uploads/1/2025-6/arquivo.jpg"
}
```

### Excluir comprovante de uma oferta

`DELETE /ofertas/:id/receipt-photo`

---

## Comprovantes (Fotos do Talão)

### Listar comprovantes por congregação e período

`GET /ofertas/receipts?congregacaoId=1&mes=6&ano=2025`

**Resposta:**
```json
[
  {
    "id": 10,
    "memberId": 2,
    "memberName": "Maria",
    "value": 100,
    "date": "2025-06-17T00:00:00.000Z",
    "service": "domingo",
    "receiptPhoto": "/uploads/1/2025-6/arquivo.jpg"
  }
]
```

---

## Despesas

### Listar despesas

`GET /despesas?congregacaoId=1&mes=6&ano=2025`

### Criar despesa

`POST /despesas`

**Body:**
```json
{
  "congregacaoId": 1,
  "descricao": "Energia elétrica",
  "valor": 150,
  "data": "2025-06-10",
  "categoria": "Luz"
}
```

---

## Relatórios

### Relatório mensal (JSON)

`GET /relatorios/mensal?congregacaoId=1&mes=6&ano=2025`

### Relatório mensal (PDF)

`GET /relatorios/mensal/pdf?congregacaoId=1&mes=6&ano=2025`

### Relatório de células

`GET /relatorios/celulas?dataInicio=2024-01-01&dataFim=2024-06-30`

### Relatório financeiro

`GET /relatorios/financeiro?dataInicio=2024-01-01&dataFim=2024-06-30`

---

## Snapshot Financeiro Mensal

Endpoint otimizado que materializa (ou retorna) um snapshot agregado por Congregação / mês.

`GET /financeiro/relatorio-mensal/snapshot?congregacaoId=1&mes=9&ano=2025`

Headers obrigatórios:
```
Authorization: Bearer <TOKEN>
schema: <schema_da_igreja>
```

Parâmetro opcional: `recomputar=true` força regenerar os dados.

Resposta (exemplo):
```json
{
  "id": 12,
  "congregacaoId": 1,
  "ano": 2025,
  "mes": 9,
  "totalDizimistas": 34,
  "totalOfertas": 57,
  "valorTotalDizimos": 18250.55,
  "valorTotalOfertas": 7250.90,
  "valorTotalReceitas": 26501.45,
  "valorComissao33": 8745.48,
  "valorRepasseCentral": 17755.97,
  "detalhesCategorias": {
    "PASTOR": { "dizimos": 5000, "ofertas": 900, "countDizimos": 5, "countOfertas": 7 },
    "DIACONO": { "dizimos": 3200, "ofertas": 1100, "countDizimos": 8, "countOfertas": 10 },
    "MEMBRO": { "dizimos": 10050.55, "ofertas": 5250, "countDizimos": 21, "countOfertas": 40 },
    "SEM_CATEGORIA": { "dizimos": 0, "ofertas": 0, "countDizimos": 0, "countOfertas": 0 }
  },
  "geradoEm": "2025-09-05T12:30:00.000Z"
}
```

Campos principais:
- `totalDizimistas`: membros distintos com algum lançamento de dízimo no mês.
- `totalOfertas`: quantidade de lançamentos de oferta.
- `valorComissao33`: 33% retido na congregação.
- `valorRepasseCentral`: restante destinado à tesouraria central.
- `detalhesCategorias`: breakdown por categoria eclesiástica.

### Exemplos (curl)

Snapshot (usa cache se já existir):
```bash
curl -H "Authorization: Bearer $TOKEN" \
  -H "schema: igreja_alpha" \
  "https://api.seudominio.com/financeiro/relatorio-mensal/snapshot?congregacaoId=1&mes=9&ano=2025"
```

Forçando recomputar:
```bash
curl -H "Authorization: Bearer $TOKEN" \
  -H "schema: igreja_alpha" \
  "https://api.seudominio.com/financeiro/relatorio-mensal/snapshot?congregacaoId=1&mes=9&ano=2025&recomputar=true"
```

Para granularidade correta, definir `categoriaEclesiastica` em cada membro (enum: `PASTOR_DIRIGENTE`, `PASTOR`, `DIACONO`, `DIACONISA`, `MEMBRO`).

### Relatório de discipulado

`GET /relatorios/discipulado/por-discipulador?dataInicio=2024-01-01&dataFim=2024-06-30`

---

## Dashboard

### Resumo financeiro anual

`GET /dashboard/resumo?congregacaoId=1&ano=2025`

**Resposta:**
```json
{
  "arrecadacaoPorMes": [1000, 1200, ...],
  "despesasPorMes": [300, 400, ...],
  "totalArrecadadoAno": 15000,
  "totalDespesasAno": 5000,
  "saldoAno": 4500
}
```

---

## Perfis e Permissões

Perfis (enum `PerfilUsuario`): `ADMIN`, `Dirigente`, `Tesoureiro`, `Secretario`, `Pastor`, `SUPERUSER`.

- **ADMIN**: Controle amplo da igreja (schema).
- **SUPERUSER**: Escopo global multi-igrejas (suporte / manutenção). Pode operar sem congregação vinculada.
- **Tesoureiro**: Gerência financeira da(s) congregação(ões) atribuída(s).
- **Pastor / Dirigente**: Gestão de membros, células, relatórios.
- **Secretario**: Apoio administrativo (cadastros / atualizações).

Header multi-tenant sempre obrigatório (inclusive login): `schema: <schema_da_igreja>`.

### Classificação de Membros para Relatórios
Campo opcional em `Member`: `categoriaEclesiastica` (enum `CategoriaEclesiastica`). Usado nos snapshots para separar dízimos/ofertas.

### Módulos Legados
Serviços antigos movidos para `src/legacy/services` (Escola de Líderes, Ministérios estendidos, Sermões, Vendas, Webhooks genéricos, etc.). Não expostos em rotas ativas – mantidos apenas por compatibilidade histórica até limpeza futura.

---

## Testes Automatizados

Ambiente de testes:
- Usa `NODE_ENV=test` para desabilitar cron diário de backup.
- Fecha conexões e intervalos (Prisma cache) no `afterAll`.
- Cada suíte cria seu schema via `/api/cadastro-inicial` e reutiliza.
- Evitar usar `/api/igrejas` diretamente nos testes (rota agora restrita).

- O backend possui testes unitários e de integração usando Jest e Supertest.
- Para rodar os testes:
  ```bash
  npm run test
  ```
- Todos os testes devem passar antes do deploy.

---

## Deploy

1. Faça o clone do projeto do GitHub no servidor.
2. Configure o arquivo `.env` com as variáveis de produção.
3. Instale as dependências:
   ```bash
   npm install
   ```
4. Rode as migrations do banco:
   ```bash
   npx prisma migrate deploy
   ```
5. Inicie o servidor:
   ```bash
   npm start
   ```
6. Acesse a documentação da API em `/api-docs`.

---

## Observações Gerais

- Para upload de arquivos, use `multipart/form-data`.
- As imagens de comprovantes ficam acessíveis em `/uploads/...`.
- Para rodar localmente:
  1. Configure `.env` com as variáveis necessárias.
  2. Rode `npx prisma migrate dev` para criar o banco.
  3. Rode `npm install` e depois `npm run dev`.
- Use ferramentas como **Insomnia** ou **Postman** para testar as rotas.
- Para métricas de saúde e performance: `GET /health`, `GET /metrics` (Prometheus) e `GET /api/health/multi-tenancy`.
- Cron de backup (02:00) desativado em ambiente de teste.
- Rate limiting distribuído e lock de provisionamento evitam saturação em ambientes multi-tenant.

---

> Para detalhes de cada endpoint, consulte as seções acima ou acesse a documentação Swagger em `/api-docs` após rodar o servidor.