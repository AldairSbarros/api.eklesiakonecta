import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { getPrisma } from "../utils/prismaDynamic";
import { provisionSchema } from "../utils/schemaProvisioner";
import fs from "fs";
import path from "path";
const { exec } = require("child_process");

interface CadastroSimples {
  nomeIgreja: string;
  nomePastor: string;
  emailPastor: string;
  senhaPastor: string;
}

export const cadastroInicial = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const {
      nomeIgreja,
      nomePastor,
      emailPastor,
      senhaPastor,
    }: CadastroSimples = req.body;

    // Validação básica
    if (!nomeIgreja || !nomePastor || !emailPastor || !senhaPastor) {
      return res.status(400).json({
        error: "Todos os campos são obrigatórios",
      });
    }

  // Provisionar schema novo (gera nome seguro único)
  const prov = await provisionSchema(nomeIgreja);
  const schemaName = prov.schema;

    // 1. Salvar no schema público (controle global)
    const prismaPublic = getPrisma("public");

    // Cria o schema no banco, se não existir ainda
    await prismaPublic.$executeRawUnsafe(
      `CREATE SCHEMA IF NOT EXISTS "${schemaName}"`
    );

  // db push já executado dentro do provisioner

    // Verifica se o email já existe no schema público
    const emailExiste = await prismaPublic.church.findFirst({
      where: { email: emailPastor },
    });

    if (emailExiste) {
      await prismaPublic.$disconnect();
      return res.status(400).json({
        error: "Este email já está cadastrado",
      });
    }

    // Hash da senha
    const senhaHash = await bcrypt.hash(senhaPastor, 10);

    // Salvar igreja no controle global (schema public)
    await prismaPublic.church.create({
      data: {
        nome: nomeIgreja,
        email: emailPastor,
        password: senhaHash,
        schema: schemaName,
      },
    });

  await prismaPublic.$disconnect();

  // 2. Criar estrutura no schema específico da igreja
  const prismaIgreja = getPrisma(schemaName);

    // Criar pastor principal no schema da igreja
    const pastor = await prismaIgreja.pastor.create({
      data: {
        nome: nomePastor,
        email: emailPastor,
        telefone: null, // ou algum valor padrão
      },
    });

    // Criar usuário admin no schema da igreja
    const usuario = await prismaIgreja.usuario.create({
      data: {
        nome: nomePastor,
        email: emailPastor,
        senha: senhaHash,
        perfil: "ADMIN",
        ativo: true,
      },
    });

    // Criar dados iniciais da igreja
    const igreja = await prismaIgreja.church.create({
      data: {
        nome: nomeIgreja,
        email: emailPastor,
        password: senhaHash,
        pastorPrincipal: {
          connect: { id: pastor.id },
        },
        schema: schemaName,
      },
    });

    await prismaIgreja.$disconnect();

    // Criar arquivo de flag indicando que sistema foi configurado
    const configFile = path.join(process.cwd(), "sistema_configurado.flag");
    const configData = {
      configurado: true,
      dataConfiguracao: new Date().toISOString(),
      primeiraIgreja: {
        nome: nomeIgreja,
        schema: schemaName,
        email: emailPastor,
      },
    };
    fs.writeFileSync(configFile, JSON.stringify(configData, null, 2));

    // Retornar dados para frontend salvar schema e token para login
    return res.status(201).json({
      success: true,
      message: "Cadastro inicial realizado com sucesso!",
      igreja: {
        nome: igreja.nome,
        schema: schemaName,
      },
      pastor: {
        nome: pastor.nome,
        email: pastor.email,
      },
    });
  } catch (error: any) {
    console.error("Erro ao criar igreja:", error);
    return res.status(500).json({
      error: "Erro ao realizar cadastro",
    });
  }
};